<?php
namespace Home\Model;
use Think\Model;
class HouseModel extends Model{
	
}