<?php

namespace Home\Model;
use Think\Model;

class WantedhouseModel extends Model{
}

?>