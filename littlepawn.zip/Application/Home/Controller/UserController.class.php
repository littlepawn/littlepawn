<?php
namespace Home\Controller;
use Think\Controller;
class UserController extends Controller{
	
}