<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>房产信息管理系统</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/bootstrap.min.css" />
    <script src="http://lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="/Public/js/bootstrap.min.js"></script>
    <style type="text/css">
    	body { 
    		padding-top: 50px; 
    	}
    	#mainbody{
    		margin: 50px auto;
    	}
		#menu{
			margin-top: 75px;
		}
		.nav-tabs{
    		width: 95%;
    		margin-left: 15px;
    	}
    </style>
  </head>
  <body>
  	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  <div class="container">
	    <div class="row">
	    	<div class="col-md-10">
	      		<a class="navbar-brand" href="/index.php/Home/Index/index">
	        		<p>房产信息管理</p>
	      		</a>
	      	</div>
	      	<div class="col-md-2">
	      		<button type="button" class="btn btn-info navbar-btn navbar-right" id="login">登录</button>
	      	</div>
	    </div>
	  </div>
	</nav>
	
	<div class="container" id="mainbody">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-9">
				<ul class="nav nav-tabs">
					    <li class="active">
					    	<a href="javascript:;" >找回密码</a>
					    </li>
				</ul>
				<div class="btn-group btn-group-lg col-md-12">
					<button type="button" class="col-md-6 btn btn-info" disabled="disabled">
						1.选择方式
					</button>
					<button type="button" class="col-md-6 btn btn-default" disabled="disabled">
						2.填写信息
					</button>
				</div>
				<div class="col-md-2"></div>
				<div class="col-md-7" id="menu">
				   	<table class="table table-striped">
						<tr><th>选择找回方式</th></tr>
						<tr><td>
							<div class="col-md-1"></div>
							<label class="col-md-4">通过手机找回</label>
							<div class="col-md-3"></div>
							<div class="col-md-3">
								<button class="btn btn-success btn-block">下一步</button>
							</div>
						</td></tr>
						<tr><td>
							<div class="col-md-1"></div>
							<label class="col-md-4">通过邮箱找回</label>
							<div class="col-md-3"></div>
							<div class="col-md-3">
								<button class="btn btn-success btn-block">下一步</button>
							</div>
						</td></tr>
					</table>
				</div>
			</div>
		</div>
	</div>
</body>
<script type="text/javascript">
	$(function(){
		$("#login").click(function(){
			window.location.href="/index.php/Home/Index/login";
		});
	});
</script>
</html>