<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>房产信息管理</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/bootstrap.min.css" />
    <script src="http://lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="/Public/js/bootstrap.min.js"></script>
    <style type="text/css">
    	body { 
    		padding-top: 50px; 
    	}
    	#name{
    		margin-left: 120px;
    	}
    	#mainbody{
    		margin: 30px auto;
    	}
    	.nav-tabs{
    		width: 95%;
    		margin-left: 15px;
    	}
    	.form{
    		margin-top: 100px;
    		margin-left: 30px;
    		text-align: center;
    	}
    	.form-horizontal{
    		margin-top: 25px;
    	}
		#typeradio{
			margin-top: 5px;
		}
		#label1{
			margin-left: -20px;
			margin-right: -20px;
		}
		#label2{
			margin-left: -20px;
			margin-right: -20px;
		}
		#label3{
			margin-left: -20px;
			margin-right: -20px;
		}
		#label4{
			margin-left: -20px;
			margin-right: -20px;
		}
		#label5{
			margin-right: -20px;
		}
		#label6{
			margin-left: -20px;
		}
		#label7{
			margin-right: -20px;
		}
		#label8{
			margin-left: -20px;
			margin-right: -20px;
		}
		#label9{
			margin-left: -50px;
			margin-right: -20px;
		}
    </style>
  </head>
 
 <body>
  	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  <div class="container">
	    <div class="row">
	    	<div class="col-md-10">
	      		<a class="navbar-brand" href="/index.php/Home/Index/main">
	        		<p>房产信息管理</p>
	      		</a>
	      	</div>
	      	<div class="col-md-2">
	      		<button type="button" class="btn btn-info navbar-btn navbar-right dropdown-toggle"  data-toggle="dropdown">
					<?php echo ($name); ?><span class="caret"></span>
				</button>
				<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" id="name">
   					 <li><a tabindex="-1" href="/index.php/Home/Index/main">返回主页</a></li>
   					 <li><a tabindex="-1" href="javascript:history.go(-1);">返回上一页</a></li>
   					 <li><a tabindex="-1" href="/index.php/Home/Index/userinfo">查看个人信息</a></li>
   					 <li><a tabindex="-1" href="/index.php/Home/Index/houserentinfo">查看发布信息</a></li>
    				 <li><a tabindex="-1" href="/index.php/Home/Index/loginout">退出</a></li>
    			</ul>
	      	</div>
	    </div>
	  </div>
	</nav>
	
	<div class="container" id="mainbody">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-9">
				 <ul class="nav nav-tabs">
					    <li class="active">
					    	<a href="javascript:;">发布信息</a>
					    </li>
				</ul>
				<div class="btn-group btn-group-lg col-md-12">
					<button type="button" class="col-md-4 btn btn-info" disabled="disabled">
						1.选择信息
					</button>
					<button type="button" class="col-md-4 btn btn-primary" disabled="disabled">
						2.发布信息
					</button>
					<button type="button" class="col-md-4 btn btn-default" disabled="disabled">
						3.发布完成
					</button>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-6">
				<div class="form-horizontal">
					<div class="form-group">
						<label class="control-label col-md-2">标题</label>
						<div class="col-md-6">
					    	<input class="form-control" type="text">
					   	</div>
					</div>
					
					<div class="form-group">
						<label class="control-label col-md-2">求租地段</label>
						<div class="col-md-3">
							<select class="form-control">
								<option>--省份--</option>
							</select>
						</div>
						<div class="col-md-3">
							<select class="form-control">
								<option>--城市--</option>
							</select>
						</div>
						<div class="col-md-3">
							<select class="form-control">
								<option>--区域--</option>
							</select>
						</div>
					</div>
					
					<div class="form-group">
						<label class="control-label col-md-2">期望</label>
						<div class="col-md-4">
							<select class="form-control">
								<option>--租金--</option>
								<option>500元/月以下</option>
								<option>500-1000元/月</option>
								<option>1000-2000元/月</option>
								<option>2000元/月以上</option>
							</select>
						</div>
						<div class="col-md-4">
							<select class="form-control">
								<option>--期望厅室--</option>
								<option>一室一厅</option>>
								<option>两室一厅</option>>
								<option>三室一厅</option>>
								<option>三室两厅</option>>
							</select>
						</div>
						
					</div>
					
					<div class="form-group">
						<label class="control-label col-md-2">内容描述</label>
						<div class="col-md-8">
							<textarea class="form-control" rows="4"></textarea>
						</div>
					</div>
					
					<div class="form-group">
						<label class="control-label col-md-2">联系人</label>
						<div class="col-md-6">
					    	<input class="form-control" type="text">
					   	</div>
					</div>
					
					<div class="form-group">
						<label class="control-label col-md-2">联系电话</label>
						<div class="col-md-6">
					    	<input class="form-control" type="text">
					   	</div>
					</div>
					
					<div class="form-group">
						<div class="col-md-2"></div>
						<div class="col-md-6">
					    	<button class="btn btn-danger btn-block btn-lg">确认并发布</button>
					   	</div>
					</div>
					
				</div>
			</div>
			<div class="col-md-5"></div>
		</div>
		
	</div>
  </body>
</html>