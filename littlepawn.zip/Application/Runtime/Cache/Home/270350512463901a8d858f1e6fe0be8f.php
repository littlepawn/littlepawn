<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>房产信息管理</title>
    <link rel="stylesheet" type="text/css" href="/Public/css/bootstrap.min.css" />
    <script src="http://lib.sinaapp.com/js/jquery/1.9.1/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="/Public/js/bootstrap.min.js"></script>
    <style type="text/css">
    	body { 
    		padding-top: 50px; 
    	}
    	#name{
    		margin-left: 120px;
    	}
    	#mainbody{
    		margin: 30px auto;
    	}
    	.nav-tabs{
    		width: 95%;
    		margin-left: 15px;
    	}
    	.form{
    		margin-top: 100px;
    		margin-left: 30px;
    		text-align: center;
    	}
    	.jumbotron{
    		margin-top: 50px;
    	}
    </style>
  </head>
 
 <body>
  	<nav class="navbar navbar-default navbar-fixed-top" role="navigation">
	  <div class="container">
	    <div class="row">
	    	<div class="col-md-10">
	      		<a class="navbar-brand" href="/index.php/Home/Index/main">
	        		<p>房产信息管理</p>
	      		</a>
	      	</div>
	      	<div class="col-md-2">
	      		<button type="button" class="btn btn-info navbar-btn navbar-right dropdown-toggle"  data-toggle="dropdown">
					<?php echo ($name); ?><span class="caret"></span>
				</button>
				<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" id="name">
   					 <li><a tabindex="-1" href="/index.php/Home/Index/main">返回主页</a></li>
   					 <li><a tabindex="-1" href="/index.php/Home/Index/userinfo">查看个人信息</a></li>
   					 <li><a tabindex="-1" href="/index.php/Home/Index/houserentinfo">查看发布信息</a></li>
    				 <li><a tabindex="-1" href="/index.php/Home/Index/loginout">退出</a></li>
    			</ul>
	      	</div>
	    </div>
	  </div>
	</nav>
	
	<div class="container" id="mainbody">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-9">
				 <ul class="nav nav-tabs">
					    <li class="active">
					    	<a href="javascript:;">发布信息</a>
					    </li>
				</ul>
				<div class="btn-group btn-group-lg col-md-12">
					<button type="button" class="col-md-4 btn btn-info" disabled="disabled">
						1.选择信息
					</button>
					<button type="button" class="col-md-4 btn btn-primary" disabled="disabled">
						2.发布信息
					</button>
					<button type="button" class="col-md-4 btn btn-warning" disabled="disabled">
						3.发布完成
					</button>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-6">
				<div class="jumbotron">
				  <h2>发布信息成功</h2>
				  <p><span id="second">3</span>秒后回到主页<a class="btn btn-primary btn-lg" href="/index.php/Home/Index/main" role="button">返回</a></p>
				</div>
			</div>
			<div class="col-md-2"></div>
		</div>
		
	</div>  	
   
  </body>
   <script type="text/javascript">  
    var num=document.getElementById("second").innerHTML;
   //获取显示秒数的元素，通过定时器来更改秒数。
  
    function count()
    {
        num--;
        document.getElementById("second").innerHTML=num;
        if(num==0)
        {
        	window.location.href="/index.php/Home/Index/main";
        }
    }
    setInterval("count()",1000);
 	</script> 
</html>